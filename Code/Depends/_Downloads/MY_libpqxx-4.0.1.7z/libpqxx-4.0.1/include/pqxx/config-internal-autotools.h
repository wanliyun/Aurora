/* Automatically generated from config.h: internal/autotools config. */
#define PACKAGE "libpqxx"
#define PACKAGE_BUGREPORT "Jeroen T. Vermeulen <jtv@xs4all.nl>"
#define PACKAGE_NAME "libpqxx"
#define PACKAGE_STRING "libpqxx 4.0.1"
#define PACKAGE_TARNAME "libpqxx"
#define PACKAGE_VERSION "4.0.1"
#define VERSION "4.0.1"
