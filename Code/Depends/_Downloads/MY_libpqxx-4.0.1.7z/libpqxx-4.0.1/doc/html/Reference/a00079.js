var a00079 =
[
    [ "reactivation_avoidance_exemption", "a00079.html#ae0b6ca7a0a7d33b88a0e0a3fb61ac240", null ],
    [ "~reactivation_avoidance_exemption", "a00079.html#a3669e53c578ba7935d5b7bdaad0d5e0b", null ],
    [ "close_connection", "a00079.html#a8397728c755c1a8b4ade039406a4155c", null ]
];