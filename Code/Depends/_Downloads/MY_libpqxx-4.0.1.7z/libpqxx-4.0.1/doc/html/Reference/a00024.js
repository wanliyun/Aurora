var a00024 =
[
    [ "handle", "a00024.html#a15bb552a890c0fb28fab2413200dee18", null ],
    [ "connectionpolicy", "a00024.html#ab46be4bfe19a8a022f441d120b6b2f09", null ],
    [ "~connectionpolicy", "a00024.html#a69870c553a2ea10b2f1fbd6073c2fb25", null ],
    [ "do_completeconnect", "a00024.html#a0bbbedd08b7f579e5a2577e97b7e09b7", null ],
    [ "do_disconnect", "a00024.html#ae74d43f05d575eb142e18ed0939de151", null ],
    [ "do_dropconnect", "a00024.html#a3358c5c2ab741a6fd798db538516a349", null ],
    [ "do_startconnect", "a00024.html#ab7c76ae54326197bcbe6d35b5bbb246f", null ],
    [ "is_ready", "a00024.html#ae6c506b9822a94dffd7e58a917d5509e", null ],
    [ "normalconnect", "a00024.html#a5b4be97db7a8739e9f4fc7e1b7ab587c", null ],
    [ "options", "a00024.html#ae3164a06f63e76709e17065bea2bf938", null ]
];