var a00080 =
[
    [ "refcount", "a00080.html#a02b194d1c4db0d3dd7d97351443bb7bd", null ],
    [ "~refcount", "a00080.html#a603b442ad845f46a19fa92970990a03e", null ],
    [ "loseref", "a00080.html#ad096a060aac9424435026f17b04d3772", null ],
    [ "makeref", "a00080.html#a7cf6cdeea44ec32c1c8b9d02f4c2f83c", null ]
];