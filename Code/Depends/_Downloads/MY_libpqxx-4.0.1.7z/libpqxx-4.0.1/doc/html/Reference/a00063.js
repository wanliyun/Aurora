var a00063 =
[
    [ "notify_listener", "a00063.html#a8a6592b38ed1c547266c05e1f3daadce", null ],
    [ "~notify_listener", "a00063.html#ac4593cefb4b75ef4373b2aa44d4bd061", null ],
    [ "Conn", "a00063.html#a183d105d5bd011d45843526004bc0f40", null ],
    [ "conn", "a00063.html#a9b6ca1f8939f82c391fecb7082364ec7", null ],
    [ "name", "a00063.html#a61fecb70ec917b3403dff4228b69a61a", null ],
    [ "operator()", "a00063.html#a0f8b3a6f5183bc9466fba30bd760af85", null ]
];