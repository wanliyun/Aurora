var a00105 =
[
    [ "transactionfocus", "a00105.html#ac1ad1a201cacde2cd35182dd3bfb66fa", null ],
    [ "reg_pending_error", "a00105.html#adae9df5aee401ccb6f1d77024d524322", null ],
    [ "register_me", "a00105.html#a267f75f541c85a38605fb6b8c66d1e0a", null ],
    [ "registered", "a00105.html#a474a6ca017e7a313bc33e7b2b5a2d1d7", null ],
    [ "unregister_me", "a00105.html#a53309d8e6bb85774cb16bf6a340cb558", null ],
    [ "m_Trans", "a00105.html#a9924dff8ce3203ca9fb9e584800ef9f4", null ]
];