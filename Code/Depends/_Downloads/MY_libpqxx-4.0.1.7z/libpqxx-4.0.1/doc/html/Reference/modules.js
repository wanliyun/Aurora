var modules =
[
    [ "Performance features", "a00199.html", null ],
    [ "Prepared statements", "a00200.html", null ],
    [ "String conversion", "a00201.html", "a00201" ],
    [ "Utility functions", "a00202.html", "a00202" ],
    [ "String escaping", "a00203.html", "a00203" ],
    [ "Connection classes", "a00204.html", "a00204" ],
    [ "Transaction classes", "a00205.html", "a00205" ],
    [ "Errorhandler", "a00206.html", "a00206" ],
    [ "Exception classes", "a00207.html", "a00207" ],
    [ "Notifications and Receivers", "a00208.html", null ],
    [ "Transactor framework", "a00209.html", null ]
];