var a00101 =
[
    [ "description", "a00101.html#adddd2eaf6dbc5feca29ce00f91b4d648", null ],
    [ "have_safe_strerror", "a00101.html#a76f2924aaefac243d3770f1f4b698211", null ],
    [ "safe_kerberos", "a00101.html#abe3528c0d2e42d6e98d80f0b45d79002", null ],
    [ "safe_libpq", "a00101.html#a3fe3fa8e530712e5228d2b5379871540", null ],
    [ "safe_query_cancel", "a00101.html#ace2546ec39e30e8793cc4a296216f259", null ],
    [ "safe_result_copy", "a00101.html#adb5c47ea21c35c73432de0d0b7e80bdb", null ]
];