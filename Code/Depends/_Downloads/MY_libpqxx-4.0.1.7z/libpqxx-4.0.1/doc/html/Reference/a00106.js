var a00106 =
[
    [ "transactor", "a00106.html#a326761951cbf1a7b38ee912a4ca3556f", null ],
    [ "Name", "a00106.html#aa6045f47cf10d83a2d3d221813d7d53c", null ],
    [ "on_abort", "a00106.html#a11e2fe0df76ccba33e0c6cd7b8f6da2d", null ],
    [ "on_commit", "a00106.html#aacc3fb9eb7993788cafe66aa88d87d6b", null ],
    [ "on_doubt", "a00106.html#ade15ec930b8c4baee2c22ceec5af9c2d", null ],
    [ "operator()", "a00106.html#ab02770d55fdda6bc4e5b4323aa53e4e8", null ]
];